This visualization project uses JQuery to read the json file. When using the Chrome browser, please disable web security of Google Chrome.
MAC:
open /Applications/Google\ Chrome.app/ --args --disable-web-security --user-data-dir

WINDOWS
"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --disable-web-security --user-data-dir="C:/ChromeDevSession"

If you don't want sitting your Browser. You can also see it on https://lsde-group16.github.io/Air-Cargo/
